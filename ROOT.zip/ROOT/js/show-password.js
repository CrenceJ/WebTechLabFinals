$("#inputpassword").password({
  eyeClass: "fa",
  eyeOpenClass: "fa-eye",
  eyeCloseClass: "fa-eye-slash",
  message: "keep your password security"
});
